package testgame;


public class NormalEnemy extends Enemy
{
	
	NormalEnemy(PathPosition p)
	{
		ImageLoader loader = ImageLoader.getLoader();
		this.enemy = loader.getImage("resources/quai1.png");
		this.position = p;
		this.anchorX = -20;
		this.anchorY = -20;
		this.velocity = 4;
                this.hp = 20;
	}
	
}
